// Ví dụ minh họa static vs instance methods

class TestClass {
  // Instance method - sẽ vào prototype
  instanceMethod() {
    return "Tôi là instance method";
  }

  // Static method - KHÔNG vào prototype
  static staticMethod() {
    return "Tôi là static method";
  }
}

// Kiểm tra static method
console.log("=== STATIC METHOD ===");
console.log("TestClass.staticMethod():", TestClass.staticMethod()); // ✅ Hoạt động
console.log(
  "TestClass.prototype.staticMethod:",
  TestClass.prototype.staticMethod
); // ❌ undefined

// Kiểm tra instance method
console.log("\n=== INSTANCE METHOD ===");
console.log(
  "TestClass.prototype.instanceMethod:",
  TestClass.prototype.instanceMethod
); // ✅ Có method
console.log("TestClass.instanceMethod:", TestClass.instanceMethod); // ❌ undefined

// Tạo instance để test
const instance = new TestClass();
console.log("\n=== VỚI INSTANCE ===");
console.log("instance.instanceMethod():", instance.instanceMethod()); // ✅ Hoạt động
// console.log("instance.staticMethod():", instance.staticMethod()); // ❌ Lỗi - không tồn tại

// Kiểm tra prototype chain
console.log("\n=== PROTOTYPE CHAIN ===");
console.log(
  "TestClass.prototype:",
  Object.getOwnPropertyNames(TestClass.prototype)
);
console.log("TestClass properties:", Object.getOwnPropertyNames(TestClass));
